<?php

print_r($model);
?>