<?php
use yii\helpers\Html;
use yii\grid\GridView;
/* @var $this yii\web\View */
$this->title = 'Administração';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-index">
 <?php

if(Yii::$app->user->identity->perfil_idperfil >2 )
{

 echo GridView::widget([
        'dataProvider' => $dataProvider,
        // 'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            
            'DataDescricao',
            'hr_cadastro',
             'area',
            // 'largura',
            // 'profundidade',
             'latitude',
             'longitude',

           // ['class' => 'yii\grid\ActionColumn'],
        ],
    ]);
}
else
{

echo GridView::widget([
        'dataProvider' => $dataProvider,
        // 'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            // 'idacompanhamento',
            // 'grupo_idgrupo',

             'UsuarioDescricao',
            'DataDescricao',
            'hr_cadastro',
             'area',
            // 'largura',
            // 'profundidade',
             'latitude',
             'longitude',

           // ['class' => 'yii\grid\ActionColumn'],
        ],
    ]);


}
 
     ?>




 

</div>
