<?php

namespace app\controllers;

use Yii;
use app\models\cPesquisa;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

use app\models\Acompanhamento;
use app\models\AcompanhamentoSearch;

class admController extends \yii\web\Controller {
	public function actionIndex() {
		$this->layout = '/adm';
		

		if(Yii::$app->user->isGuest){
			return $this->redirect('/site/login');
		}

	if(Yii::$app->user->identity->perfil_idperfil >2 ){
 		
 		  $searchModel = new AcompanhamentoSearch([
               'usuario_idusuario' =>  Yii::$app->user->identity->idusuario ]
        	);
 		}
 		else
 		{
 			 $searchModel = new AcompanhamentoSearch();
 		}

        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);


        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
	}




}
